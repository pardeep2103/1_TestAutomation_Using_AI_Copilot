package stepdef;

import io.cucumber.java.en.*;

import static org.testng.Assert.assertEquals;


import Pages.HomePage;
import Pages.LoginPage;
import Utlities.base;

public class LoginSteps extends base {
    LoginPage loginPage;
    HomePage homePage;

    @Given("I am on the SauceDemo login page")
    public void i_am_on_the_sauce_demo_login_page() {
    	launch_chrome();
        loginPage = new LoginPage(driver);
    }

    @When("I enter username {string} and password {string}")
    public void i_enter_username_and_password(String username, String password) {
        loginPage = new LoginPage(driver);

        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
    }

    @And("I click on the login button")
    public void i_click_on_the_login_button() {
        loginPage.clickLogin();
    }

    @Then("I should be redirected to the home page with title {string}")
    public void i_should_be_redirected_to_the_home_page_with_title(String expectedTitle) {
        homePage = new HomePage(driver);
        String actualTitle = homePage.getPageTitleText();
        assertEquals(expectedTitle, actualTitle);
        driver.quit();
    }
}