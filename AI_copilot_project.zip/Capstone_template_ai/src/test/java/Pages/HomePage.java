package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    WebDriver driver;

    // Constructor
    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Example element on home page (Products title)
    @FindBy(xpath = "//span[@class='title']")
     WebElement pageTitle;

    // Method to get page title text
    public String getPageTitleText() {
        return pageTitle.getText();
    }
}