package stepdef;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Pages.home_page;
import Pages.login_page;
import Utlities.base;
import io.cucumber.java.en.*;

public class login_steps extends base {

    login_page login;
    home_page home;

    @Given("the user enter a username {string}")
    public void the_username(String username) {
    	launch_chrome();
        login = new login_page(driver);
        login.enter_uname(username);
    }

    @When("the user enter a password {string}")
    public void the_password(String password) {
        login.enter_password(password);
    }

    @And("the user click login button")
    public void the_user_click() {
        login.click_button();
    }

    @Then("the user should be navigated to the home page")
    public void the_user_should_be_navigated_to_the_home_page() {
    	home = new home_page(driver);
        String actualHeader = home.enter_prodcuttitle();
        Assert.assertEquals("Products", actualHeader);
        System.out.println("Homepage verified successfully with header: " + actualHeader);
        driver.quit();
    }
}