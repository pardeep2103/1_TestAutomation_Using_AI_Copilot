package Utlities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class base {

public static WebDriver driver;
  

	   public void launch_chrome() {
	        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
	        driver = new ChromeDriver();
	    	driver.get("https://www.saucedemo.com/");
	       
	        driver.manage().window().maximize();
	    }
   

   
}